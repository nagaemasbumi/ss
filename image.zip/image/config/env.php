<?php
/**
 * ========================================
 * TELEGRAM IMAGE GENERATOR BOT
 * OPENAI GPT-IMAGE-1
 * PHP 8.2 - PRODUCTION READY
 * ========================================
 */

// ========================================
// FILE: config/env.php
// ========================================

declare(strict_types=1);

return [
    'telegram' => [
        'bot_token' => getenv('TELEGRAM_BOT_TOKEN') ?: '8592103923:AAFiwk2LcRw9xo82ErM9G8w4p-1FG2-DVb8',
        'webhook_secret' => getenv('TELEGRAM_WEBHOOK_SECRET') ?: 'https://68.183.233.201/index.php',
    ],
    'openai' => [
        'api_key' => getenv('OPENAI_API_KEY') ?: 'key : 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',
        'organization' => getenv('OPENAI_ORG') ?: null,
    ],
];
