<?php
// ========================================
// FILE: config/settings.php
// ========================================

declare(strict_types=1);

return [
    'bot' => [
        'name' => 'AI Image Generator Bot',
        'version' => '1.0.0',
        'max_prompt_length' => 500,
        'rate_limit_seconds' => 30,
        'rate_limit_requests' => 5,
    ],
    'image' => [
        'default_style' => 'realistic',
        'webp_quality' => 85,
        'styles' => [
            'realistic' => 'realistic',
            'anime' => 'anime illustration',
            'cyberpunk' => 'cinematic cyberpunk',
            'vector' => 'flat vector',
            'digital' => 'digital painting',
        ],
        'sizes' => [
            '1080x1080' => ['width' => 1080, 'height' => 1080, 'aspect' => '1:1', 'openai_size' => '1024x1024'],
            '1920x1080' => ['width' => 1920, 'height' => 1080, 'aspect' => '16:9', 'openai_size' => '1792x1024'],
            '1080x1920' => ['width' => 1080, 'height' => 1920, 'aspect' => '9:16', 'openai_size' => '1024x1792'],
        ],
        'negative_prompt' => 'blurry, low quality, distorted, watermark, logo, text, jpeg artifacts',
    ],
    'paths' => [
        'storage' => __DIR__ . '/../storage/',
        'tmp' => __DIR__ . '/../storage/tmp/',
        'state' => __DIR__ . '/../storage/state.json',
        'logs' => __DIR__ . '/../logs/bot.log',
    ],
];
