<?php
// ========================================
// FILE: setup_webhook.php (Utility Script)
// ========================================

declare(strict_types=1);

/**
 * Run this script once to set up the Telegram webhook
 * Usage: php setup_webhook.php <webhook_url>
 */

if (php_sapi_name() !== 'cli') {
    die('This script must be run from command line');
}

if ($argc < 2) {
    echo "Usage: php setup_webhook.php <webhook_url>\n";
    echo "Example: php setup_webhook.php https://68.183.233.201/index.php\n";
    exit(1);
}

$webhookUrl = $argv[1];

// Load configuration
$env = require __DIR__ . '/config/env.php';

$botToken = $env['telegram']['bot_token'];
$apiUrl = "https://api.telegram.org/bot{$botToken}/setWebhook";

$params = [
    'url' => $webhookUrl,
    'allowed_updates' => json_encode(['message', 'callback_query']),
    'drop_pending_updates' => true,
];

$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $apiUrl,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $params,
    CURLOPT_RETURNTRANSFER => true,
]);

$response = curl_exec($ch);
$error = curl_error($ch);
curl_close($ch);

if ($error) {
    echo "cURL Error: {$error}\n";
    exit(1);
}

$result = json_decode($response, true);

if ($result['ok']) {
    echo "✅ Webhook set successfully!\n";
    echo "URL: {$webhookUrl}\n";
} else {
    echo "❌ Failed to set webhook\n";
    echo "Error: " . ($result['description'] ?? 'Unknown error') . "\n";
    exit(1);
}
