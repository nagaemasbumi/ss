<?php
// ========================================
// FILE: core/OpenAI.php
// ========================================

declare(strict_types=1);

namespace Core;

class OpenAI
{
    private string $apiKey;
    private ?string $organization;
    private string $baseUrl = 'https://api.openai.com/v1/';

    public function __construct(string $apiKey, ?string $organization = null)
    {
        $this->apiKey = $apiKey;
        $this->organization = $organization;
    }

    /**
     * Generate image using GPT-IMAGE-1
     */
    public function generateImage(string $prompt, string $size = '1024x1024'): array
    {
        $payload = [
            'model' => 'gpt-image-1',
            'prompt' => $prompt,
            'n' => 1,
            'size' => $size,
            'response_format' => 'b64_json',
        ];

        return $this->request('images/generations', $payload);
    }

    /**
     * Make API request to OpenAI
     */
    private function request(string $endpoint, array $payload): array
    {
        $ch = curl_init();
        
        $headers = [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $this->apiKey,
        ];
        
        if ($this->organization) {
            $headers[] = 'OpenAI-Organization: ' . $this->organization;
        }
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $this->baseUrl . $endpoint,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 300,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        
        curl_close($ch);
        
        if ($error) {
            throw new \RuntimeException("OpenAI API cURL error: {$error}");
        }
        
        $result = json_decode($response, true);
        
        if ($httpCode !== 200) {
            $errorMessage = $result['error']['message'] ?? 'Unknown OpenAI API error';
            throw new \RuntimeException("OpenAI API error ({$httpCode}): {$errorMessage}");
        }
        
        return $result;
    }

    /**
     * Build the final prompt with template
     */
    public static function buildPrompt(
        string $userPrompt,
        string $style = 'realistic',
        string $aspectRatio = '1:1'
    ): string {
        $template = "{STYLE}, highly detailed, professional lighting, ultra sharp focus, " .
                    "{USER_PROMPT}, " .
                    "clean background, cinematic composition, " .
                    "aspect ratio optimized for {ASPECT_RATIO}, " .
                    "no watermark, no logo, no text";
        
        $finalPrompt = str_replace(
            ['{STYLE}', '{USER_PROMPT}', '{ASPECT_RATIO}'],
            [$style, $userPrompt, $aspectRatio],
            $template
        );
        
        return $finalPrompt;
    }
}
