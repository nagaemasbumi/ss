<?php
// ========================================
// FILE: core/ImageService.php
// ========================================

declare(strict_types=1);

namespace Core;

class ImageService
{
    private string $tmpPath;
    private int $webpQuality;

    public function __construct(string $tmpPath, int $webpQuality = 85)
    {
        $this->tmpPath = rtrim($tmpPath, '/') . '/';
        $this->webpQuality = $webpQuality;
        
        if (!is_dir($this->tmpPath)) {
            mkdir($this->tmpPath, 0755, true);
        }
    }

    /**
     * Save base64 image to temporary file
     */
    public function saveBase64Image(string $base64Data, string $filename): string
    {
        $imageData = base64_decode($base64Data);
        
        if ($imageData === false) {
            throw new \RuntimeException('Failed to decode base64 image data');
        }
        
        $filePath = $this->tmpPath . $filename;
        
        if (file_put_contents($filePath, $imageData) === false) {
            throw new \RuntimeException('Failed to save image file');
        }
        
        return $filePath;
    }

    /**
     * Convert image to WEBP and resize to target dimensions
     */
    public function convertToWebp(
        string $sourcePath,
        int $targetWidth,
        int $targetHeight,
        string $outputFilename
    ): string {
        $outputPath = $this->tmpPath . $outputFilename;
        
        // Check if ImageMagick is available
        if ($this->hasImageMagick()) {
            return $this->convertWithImageMagick($sourcePath, $targetWidth, $targetHeight, $outputPath);
        }
        
        // Fallback to GD library
        return $this->convertWithGD($sourcePath, $targetWidth, $targetHeight, $outputPath);
    }

    /**
     * Check if ImageMagick is available
     */
    private function hasImageMagick(): bool
    {
        return extension_loaded('imagick');
    }

    /**
     * Convert using ImageMagick
     */
    private function convertWithImageMagick(
        string $sourcePath,
        int $targetWidth,
        int $targetHeight,
        string $outputPath
    ): string {
        $imagick = new \Imagick($sourcePath);
        
        // Get original dimensions
        $origWidth = $imagick->getImageWidth();
        $origHeight = $imagick->getImageHeight();
        
        // Calculate aspect ratios
        $targetRatio = $targetWidth / $targetHeight;
        $origRatio = $origWidth / $origHeight;
        
        // Resize and crop to fit target dimensions
        if ($origRatio > $targetRatio) {
            // Original is wider - fit height, crop width
            $newHeight = $targetHeight;
            $newWidth = (int)($origWidth * ($targetHeight / $origHeight));
            $imagick->resizeImage($newWidth, $newHeight, \Imagick::FILTER_LANCZOS, 1);
            
            $cropX = (int)(($newWidth - $targetWidth) / 2);
            $imagick->cropImage($targetWidth, $targetHeight, $cropX, 0);
        } else {
            // Original is taller - fit width, crop height
            $newWidth = $targetWidth;
            $newHeight = (int)($origHeight * ($targetWidth / $origWidth));
            $imagick->resizeImage($newWidth, $newHeight, \Imagick::FILTER_LANCZOS, 1);
            
            $cropY = (int)(($newHeight - $targetHeight) / 2);
            $imagick->cropImage($targetWidth, $targetHeight, 0, $cropY);
        }
        
        // Set WEBP format and quality
        $imagick->setImageFormat('webp');
        $imagick->setImageCompressionQuality($this->webpQuality);
        
        // Strip metadata for smaller file size
        $imagick->stripImage();
        
        // Write output
        $imagick->writeImage($outputPath);
        $imagick->destroy();
        
        return $outputPath;
    }

    /**
     * Convert using GD library
     */
    private function convertWithGD(
        string $sourcePath,
        int $targetWidth,
        int $targetHeight,
        string $outputPath
    ): string {
        // Detect source image type
        $imageInfo = getimagesize($sourcePath);
        
        if ($imageInfo === false) {
            throw new \RuntimeException('Failed to read source image');
        }
        
        $mimeType = $imageInfo['mime'];
        
        // Load source image
        $sourceImage = match ($mimeType) {
            'image/jpeg' => imagecreatefromjpeg($sourcePath),
            'image/png' => imagecreatefrompng($sourcePath),
            'image/gif' => imagecreatefromgif($sourcePath),
            'image/webp' => imagecreatefromwebp($sourcePath),
            default => throw new \RuntimeException("Unsupported image type: {$mimeType}"),
        };
        
        if ($sourceImage === false) {
            throw new \RuntimeException('Failed to create image from source');
        }
        
        $origWidth = imagesx($sourceImage);
        $origHeight = imagesy($sourceImage);
        
        // Calculate crop dimensions
        $targetRatio = $targetWidth / $targetHeight;
        $origRatio = $origWidth / $origHeight;
        
        if ($origRatio > $targetRatio) {
            // Crop width
            $srcHeight = $origHeight;
            $srcWidth = (int)($origHeight * $targetRatio);
            $srcX = (int)(($origWidth - $srcWidth) / 2);
            $srcY = 0;
        } else {
            // Crop height
            $srcWidth = $origWidth;
            $srcHeight = (int)($origWidth / $targetRatio);
            $srcX = 0;
            $srcY = (int)(($origHeight - $srcHeight) / 2);
        }
        
        // Create target image
        $targetImage = imagecreatetruecolor($targetWidth, $targetHeight);
        
        if ($targetImage === false) {
            imagedestroy($sourceImage);
            throw new \RuntimeException('Failed to create target image');
        }
        
        // Enable alpha blending for transparency
        imagealphablending($targetImage, false);
        imagesavealpha($targetImage, true);
        
        // Resize and crop
        $result = imagecopyresampled(
            $targetImage,
            $sourceImage,
            0, 0,
            $srcX, $srcY,
            $targetWidth, $targetHeight,
            $srcWidth, $srcHeight
        );
        
        if (!$result) {
            imagedestroy($sourceImage);
            imagedestroy($targetImage);
            throw new \RuntimeException('Failed to resample image');
        }
        
        // Save as WEBP
        $webpResult = imagewebp($targetImage, $outputPath, $this->webpQuality);
        
        // Cleanup
        imagedestroy($sourceImage);
        imagedestroy($targetImage);
        
        if (!$webpResult) {
            throw new \RuntimeException('Failed to save WEBP image');
        }
        
        return $outputPath;
    }

    /**
     * Delete temporary file
     */
    public function deleteFile(string $filePath): bool
    {
        if (file_exists($filePath)) {
            return unlink($filePath);
        }
        return true;
    }

    /**
     * Clean up old temporary files (older than 1 hour)
     */
    public function cleanupOldFiles(int $maxAge = 3600): int
    {
        $deleted = 0;
        $files = glob($this->tmpPath . '*');
        
        foreach ($files as $file) {
            if (is_file($file) && (time() - filemtime($file)) > $maxAge) {
                if (unlink($file)) {
                    $deleted++;
                }
            }
        }
        
        return $deleted;
    }

    /**
     * Generate unique filename
     */
    public static function generateFilename(string $extension = 'png'): string
    {
        return uniqid('img_', true) . '.' . $extension;
    }
}
