<?php
// ========================================
// FILE: core/Telegram.php
// ========================================

declare(strict_types=1);

namespace Core;

class Telegram
{
    private string $token;
    private string $apiUrl;

    public function __construct(string $token)
    {
        $this->token = $token;
        $this->apiUrl = "https://api.telegram.org/bot{$token}/";
    }

    /**
     * Send API request to Telegram
     */
    public function request(string $method, array $params = []): array
    {
        $ch = curl_init();
        
        $url = $this->apiUrl . $method;
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($params),
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        
        curl_close($ch);
        
        if ($error) {
            throw new \RuntimeException("Telegram API cURL error: {$error}");
        }
        
        $result = json_decode($response, true);
        
        if (!$result['ok']) {
            throw new \RuntimeException("Telegram API error: " . ($result['description'] ?? 'Unknown error'));
        }
        
        return $result;
    }

    /**
     * Send text message
     */
    public function sendMessage(int|string $chatId, string $text, array $options = []): array
    {
        $params = array_merge([
            'chat_id' => $chatId,
            'text' => $text,
            'parse_mode' => 'HTML',
        ], $options);
        
        return $this->request('sendMessage', $params);
    }

    /**
     * Send inline keyboard
     */
    public function sendMessageWithKeyboard(
        int|string $chatId,
        string $text,
        array $keyboard
    ): array {
        return $this->sendMessage($chatId, $text, [
            'reply_markup' => [
                'inline_keyboard' => $keyboard,
            ],
        ]);
    }

    /**
     * Send photo from file path
     */
    public function sendPhoto(int|string $chatId, string $filePath, string $caption = ''): array
    {
        $ch = curl_init();
        
        $params = [
            'chat_id' => $chatId,
            'photo' => new \CURLFile($filePath),
            'caption' => $caption,
        ];
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $this->apiUrl . 'sendPhoto',
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $params,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 120,
        ]);
        
        $response = curl_exec($ch);
        $error = curl_error($ch);
        
        curl_close($ch);
        
        if ($error) {
            throw new \RuntimeException("Telegram sendPhoto cURL error: {$error}");
        }
        
        $result = json_decode($response, true);
        
        if (!$result['ok']) {
            throw new \RuntimeException("Telegram sendPhoto error: " . ($result['description'] ?? 'Unknown error'));
        }
        
        return $result;
    }

    /**
     * Send document from file path
     */
    public function sendDocument(int|string $chatId, string $filePath, string $caption = ''): array
    {
        $ch = curl_init();
        
        $params = [
            'chat_id' => $chatId,
            'document' => new \CURLFile($filePath),
            'caption' => $caption,
        ];
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $this->apiUrl . 'sendDocument',
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $params,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 120,
        ]);
        
        $response = curl_exec($ch);
        $error = curl_error($ch);
        
        curl_close($ch);
        
        if ($error) {
            throw new \RuntimeException("Telegram sendDocument cURL error: {$error}");
        }
        
        $result = json_decode($response, true);
        
        if (!$result['ok']) {
            throw new \RuntimeException("Telegram sendDocument error: " . ($result['description'] ?? 'Unknown error'));
        }
        
        return $result;
    }

    /**
     * Answer callback query
     */
    public function answerCallbackQuery(string $callbackQueryId, string $text = '', bool $showAlert = false): array
    {
        return $this->request('answerCallbackQuery', [
            'callback_query_id' => $callbackQueryId,
            'text' => $text,
            'show_alert' => $showAlert,
        ]);
    }

    /**
     * Edit message text
     */
    public function editMessageText(int|string $chatId, int $messageId, string $text): array
    {
        return $this->request('editMessageText', [
            'chat_id' => $chatId,
            'message_id' => $messageId,
            'text' => $text,
            'parse_mode' => 'HTML',
        ]);
    }

    /**
     * Send chat action (typing, upload_photo, etc.)
     */
    public function sendChatAction(int|string $chatId, string $action = 'typing'): array
    {
        return $this->request('sendChatAction', [
            'chat_id' => $chatId,
            'action' => $action,
        ]);
    }

    /**
     * Delete message
     */
    public function deleteMessage(int|string $chatId, int $messageId): array
    {
        return $this->request('deleteMessage', [
            'chat_id' => $chatId,
            'message_id' => $messageId,
        ]);
    }
}
