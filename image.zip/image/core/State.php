<?php
// ========================================
// FILE: core/State.php
// ========================================

declare(strict_types=1);

namespace Core;

class State
{
    public const IDLE = 'IDLE';
    public const WAITING_PROMPT = 'WAITING_PROMPT';
    public const WAITING_SIZE = 'WAITING_SIZE';
    public const GENERATING = 'GENERATING';

    private string $stateFile;
    private array $states = [];

    public function __construct(string $stateFile)
    {
        $this->stateFile = $stateFile;
        $this->load();
    }

    /**
     * Load states from JSON file
     */
    private function load(): void
    {
        if (file_exists($this->stateFile)) {
            $content = file_get_contents($this->stateFile);
            $data = json_decode($content, true);
            $this->states = is_array($data) ? $data : [];
        }
    }

    /**
     * Save states to JSON file
     */
    private function save(): void
    {
        $dir = dirname($this->stateFile);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        
        file_put_contents(
            $this->stateFile,
            json_encode($this->states, JSON_PRETTY_PRINT),
            LOCK_EX
        );
    }

    /**
     * Get user state
     */
    public function getState(int|string $userId): string
    {
        return $this->states[(string)$userId]['state'] ?? self::IDLE;
    }

    /**
     * Set user state
     */
    public function setState(int|string $userId, string $state): void
    {
        $userId = (string)$userId;
        
        if (!isset($this->states[$userId])) {
            $this->states[$userId] = [
                'state' => self::IDLE,
                'data' => [],
                'rate_limit' => [],
            ];
        }
        
        $this->states[$userId]['state'] = $state;
        $this->states[$userId]['updated_at'] = time();
        $this->save();
    }

    /**
     * Get user data
     */
    public function getData(int|string $userId, string $key = null): mixed
    {
        $userId = (string)$userId;
        $data = $this->states[$userId]['data'] ?? [];
        
        if ($key === null) {
            return $data;
        }
        
        return $data[$key] ?? null;
    }

    /**
     * Set user data
     */
    public function setData(int|string $userId, string $key, mixed $value): void
    {
        $userId = (string)$userId;
        
        if (!isset($this->states[$userId])) {
            $this->states[$userId] = [
                'state' => self::IDLE,
                'data' => [],
                'rate_limit' => [],
            ];
        }
        
        $this->states[$userId]['data'][$key] = $value;
        $this->save();
    }

    /**
     * Clear user data
     */
    public function clearData(int|string $userId): void
    {
        $userId = (string)$userId;
        
        if (isset($this->states[$userId])) {
            $this->states[$userId]['data'] = [];
            $this->save();
        }
    }

    /**
     * Reset user to IDLE state
     */
    public function reset(int|string $userId): void
    {
        $userId = (string)$userId;
        
        $this->states[$userId] = [
            'state' => self::IDLE,
            'data' => [],
            'rate_limit' => $this->states[$userId]['rate_limit'] ?? [],
            'updated_at' => time(),
        ];
        
        $this->save();
    }

    /**
     * Check rate limit
     */
    public function checkRateLimit(int|string $userId, int $maxRequests, int $windowSeconds): bool
    {
        $userId = (string)$userId;
        $now = time();
        
        if (!isset($this->states[$userId]['rate_limit'])) {
            $this->states[$userId]['rate_limit'] = [];
        }
        
        // Clean old entries
        $this->states[$userId]['rate_limit'] = array_filter(
            $this->states[$userId]['rate_limit'],
            fn($timestamp) => ($now - $timestamp) < $windowSeconds
        );
        
        // Check if within limit
        if (count($this->states[$userId]['rate_limit']) >= $maxRequests) {
            return false;
        }
        
        // Add current request
        $this->states[$userId]['rate_limit'][] = $now;
        $this->save();
        
        return true;
    }

    /**
     * Clean up old states (older than 24 hours)
     */
    public function cleanup(int $maxAge = 86400): int
    {
        $now = time();
        $cleaned = 0;
        
        foreach ($this->states as $userId => $data) {
            $updatedAt = $data['updated_at'] ?? 0;
            
            if (($now - $updatedAt) > $maxAge) {
                unset($this->states[$userId]);
                $cleaned++;
            }
        }
        
        if ($cleaned > 0) {
            $this->save();
        }
        
        return $cleaned;
    }
}
