<?php
// ========================================
// FILE: handlers/CallbackHandler.php
// ========================================

declare(strict_types=1);

namespace Handlers;

use Core\Telegram;
use Core\OpenAI;
use Core\ImageService;
use Core\State;

class CallbackHandler
{
    private Telegram $telegram;
    private OpenAI $openai;
    private ImageService $imageService;
    private State $state;
    private array $settings;
    private string $logFile;

    public function __construct(
        Telegram $telegram,
        OpenAI $openai,
        ImageService $imageService,
        State $state,
        array $settings
    ) {
        $this->telegram = $telegram;
        $this->openai = $openai;
        $this->imageService = $imageService;
        $this->state = $state;
        $this->settings = $settings;
        $this->logFile = $settings['paths']['logs'];
    }

    /**
     * Handle callback query
     */
    public function handle(array $callbackQuery): void
    {
        $callbackId = $callbackQuery['id'];
        $chatId = $callbackQuery['message']['chat']['id'];
        $messageId = $callbackQuery['message']['message_id'];
        $userId = $callbackQuery['from']['id'];
        $data = $callbackQuery['data'] ?? '';
        
        // Validate callback data
        if (!$this->validateCallbackData($data)) {
            $this->telegram->answerCallbackQuery($callbackId, '⚠️ Invalid action', true);
            return;
        }
        
        // Handle cancel action
        if ($data === 'cancel') {
            $this->handleCancel($callbackId, $chatId, $messageId, $userId);
            return;
        }
        
        // Handle size selection
        if (str_starts_with($data, 'imgsize:')) {
            $this->handleSizeSelection($callbackId, $chatId, $messageId, $userId, $data);
            return;
        }
        
        $this->telegram->answerCallbackQuery($callbackId, '⚠️ Unknown action');
    }

    /**
     * Validate callback data format
     */
    private function validateCallbackData(string $data): bool
    {
        if ($data === 'cancel') {
            return true;
        }
        
        if (str_starts_with($data, 'imgsize:')) {
            $size = substr($data, 8);
            return isset($this->settings['image']['sizes'][$size]);
        }
        
        return false;
    }

    /**
     * Handle cancel callback
     */
    private function handleCancel(
        string $callbackId,
        int|string $chatId,
        int $messageId,
        int|string $userId
    ): void {
        $this->state->reset($userId);
        $this->telegram->answerCallbackQuery($callbackId, 'Operation cancelled');
        $this->telegram->editMessageText($chatId, $messageId, '❌ Operation cancelled.\n\nType /imagine to start again.');
    }

    /**
     * Handle size selection callback
     */
    private function handleSizeSelection(
        string $callbackId,
        int|string $chatId,
        int $messageId,
        int|string $userId,
        string $data
    ): void {
        // Check current state
        $currentState = $this->state->getState($userId);
        
        if ($currentState !== State::WAITING_SIZE) {
            $this->telegram->answerCallbackQuery($callbackId, '⚠️ Session expired. Please start again.', true);
            $this->state->reset($userId);
            return;
        }
        
        // Get prompt from state
        $prompt = $this->state->getData($userId, 'prompt');
        
        if (empty($prompt)) {
            $this->telegram->answerCallbackQuery($callbackId, '⚠️ Prompt not found. Please start again.', true);
            $this->state->reset($userId);
            return;
        }
        
        // Parse size from callback data
        $sizeKey = substr($data, 8); // Remove 'imgsize:' prefix
        $sizeConfig = $this->settings['image']['sizes'][$sizeKey] ?? null;
        
        if (!$sizeConfig) {
            $this->telegram->answerCallbackQuery($callbackId, '⚠️ Invalid size selected.', true);
            return;
        }
        
        // Answer callback and update message
        $this->telegram->answerCallbackQuery($callbackId, '🎨 Generating image...');
        $this->telegram->editMessageText(
            $chatId,
            $messageId,
            "🎨 <b>Generating your image...</b>\n\n" .
            "Size: {$sizeKey}\n" .
            "This may take a moment. Please wait..."
        );
        
        // Set state to generating
        $this->state->setState($userId, State::GENERATING);
        $this->state->setData($userId, 'size', $sizeKey);
        
        // Send typing action
        $this->telegram->sendChatAction($chatId, 'upload_photo');
        
        // Generate image
        try {
            $this->generateAndSendImage($chatId, $userId, $prompt, $sizeConfig);
        } catch (\Throwable $e) {
            $this->logError("Image generation error for user {$userId}: " . $e->getMessage());
            $this->telegram->sendMessage(
                $chatId,
                "❌ <b>Error generating image</b>\n\n" .
                "Sorry, something went wrong. Please try again later.\n\n" .
                "Type /imagine to start again."
            );
        }
        
        // Reset state
        $this->state->reset($userId);
    }

    /**
     * Generate image and send to user
     */
    private function generateAndSendImage(
        int|string $chatId,
        int|string $userId,
        string $userPrompt,
        array $sizeConfig
    ): void {
        $targetWidth = $sizeConfig['width'];
        $targetHeight = $sizeConfig['height'];
        $aspectRatio = $sizeConfig['aspect'];
        $openaiSize = $sizeConfig['openai_size'];
        
        // Build final prompt
        $defaultStyle = $this->settings['image']['default_style'];
        $finalPrompt = OpenAI::buildPrompt($userPrompt, $defaultStyle, $aspectRatio);
        
        $this->logInfo("Generating image for user {$userId}: " . mb_substr($userPrompt, 0, 100));
        
        // Call OpenAI API
        $response = $this->openai->generateImage($finalPrompt, $openaiSize);
        
        if (empty($response['data'][0]['b64_json'])) {
            throw new \RuntimeException('No image data received from OpenAI');
        }
        
        $base64Image = $response['data'][0]['b64_json'];
        
        // Save temporary image
        $tempFilename = ImageService::generateFilename('png');
        $tempPath = $this->imageService->saveBase64Image($base64Image, $tempFilename);
        
        try {
            // Convert to WEBP
            $webpFilename = ImageService::generateFilename('webp');
            $webpPath = $this->imageService->convertToWebp(
                $tempPath,
                $targetWidth,
                $targetHeight,
                $webpFilename
            );
            
            // Send image to user
            $caption = "🎨 <b>Image Generated!</b>\n\n" .
                      "Size: {$targetWidth}x{$targetHeight}\n" .
                      "Prompt: <i>" . htmlspecialchars(mb_substr($userPrompt, 0, 150)) . 
                      (mb_strlen($userPrompt) > 150 ? '...' : '') . "</i>";
            
            $this->telegram->sendChatAction($chatId, 'upload_document');
            $this->telegram->sendDocument($chatId, $webpPath, $caption);
            
            $this->logInfo("Image sent to user {$userId}");
            
        } finally {
            // Cleanup temporary files
            $this->imageService->deleteFile($tempPath);
            if (isset($webpPath)) {
                $this->imageService->deleteFile($webpPath);
            }
        }
    }

    /**
     * Log error message
     */
    private function logError(string $message): void
    {
        $this->log('ERROR', $message);
    }

    /**
     * Log info message
     */
    private function logInfo(string $message): void
    {
        $this->log('INFO', $message);
    }

    /**
     * Write to log file
     */
    private function log(string $level, string $message): void
    {
        $dir = dirname($this->logFile);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        
        $timestamp = date('Y-m-d H:i:s');
        $logLine = "[{$timestamp}] [{$level}] {$message}" . PHP_EOL;
        
        file_put_contents($this->logFile, $logLine, FILE_APPEND | LOCK_EX);
    }
}
