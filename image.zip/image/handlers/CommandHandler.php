<?php
// ========================================
// FILE: handlers/CommandHandler.php
// ========================================

declare(strict_types=1);

namespace Handlers;

use Core\Telegram;
use Core\State;

class CommandHandler
{
    private Telegram $telegram;
    private State $state;
    private array $settings;

    public function __construct(Telegram $telegram, State $state, array $settings)
    {
        $this->telegram = $telegram;
        $this->state = $state;
        $this->settings = $settings;
    }

    /**
     * Handle incoming command
     */
    public function handle(array $message): void
    {
        $chatId = $message['chat']['id'];
        $userId = $message['from']['id'];
        $text = $message['text'] ?? '';
        
        // Extract command
        $command = $this->extractCommand($text);
        
        match ($command) {
            '/start' => $this->handleStart($chatId, $userId),
            '/imagine' => $this->handleImagine($chatId, $userId),
            '/cancel' => $this->handleCancel($chatId, $userId),
            '/help' => $this->handleHelp($chatId),
            '/styles' => $this->handleStyles($chatId),
            default => null,
        };
    }

    /**
     * Extract command from text
     */
    private function extractCommand(string $text): string
    {
        $parts = explode(' ', trim($text));
        $command = $parts[0] ?? '';
        
        // Remove bot username if present (e.g., /start@BotName)
        if (str_contains($command, '@')) {
            $command = explode('@', $command)[0];
        }
        
        return strtolower($command);
    }

    /**
     * Handle /start command
     */
    private function handleStart(int|string $chatId, int|string $userId): void
    {
        $this->state->reset($userId);
        
        $welcomeMessage = "🎨 <b>Welcome to AI Image Generator Bot!</b>\n\n" .
                         "I can generate beautiful images from your text descriptions using AI.\n\n" .
                         "<b>Commands:</b>\n" .
                         "• /imagine - Generate a new image\n" .
                         "• /styles - View available styles\n" .
                         "• /cancel - Cancel current operation\n" .
                         "• /help - Show help message\n\n" .
                         "Type /imagine to get started!";
        
        $this->telegram->sendMessage($chatId, $welcomeMessage);
    }

    /**
     * Handle /imagine command
     */
    private function handleImagine(int|string $chatId, int|string $userId): void
    {
        // Check rate limit
        $maxRequests = $this->settings['bot']['rate_limit_requests'];
        $windowSeconds = $this->settings['bot']['rate_limit_seconds'];
        
        if (!$this->state->checkRateLimit($userId, $maxRequests, $windowSeconds)) {
            $this->telegram->sendMessage(
                $chatId,
                "⚠️ Rate limit exceeded. Please wait a moment before trying again."
            );
            return;
        }
        
        // Set state to waiting for prompt
        $this->state->setState($userId, State::WAITING_PROMPT);
        $this->state->clearData($userId);
        
        $promptMessage = "📝 <b>Please send your image prompt</b>\n\n" .
                        "Describe what you want to see in the image. Be specific and detailed!\n\n" .
                        "<i>Example: A majestic lion standing on a rock at sunset, " .
                        "golden light illuminating its mane</i>\n\n" .
                        "Max length: {$this->settings['bot']['max_prompt_length']} characters\n\n" .
                        "Type /cancel to abort.";
        
        $this->telegram->sendMessage($chatId, $promptMessage);
    }

    /**
     * Handle /cancel command
     */
    private function handleCancel(int|string $chatId, int|string $userId): void
    {
        $currentState = $this->state->getState($userId);
        
        if ($currentState === State::IDLE) {
            $this->telegram->sendMessage($chatId, "ℹ️ Nothing to cancel.");
            return;
        }
        
        $this->state->reset($userId);
        $this->telegram->sendMessage($chatId, "✅ Operation cancelled. Type /imagine to start again.");
    }

    /**
     * Handle /help command
     */
    private function handleHelp(int|string $chatId): void
    {
        $helpMessage = "🤖 <b>AI Image Generator Bot - Help</b>\n\n" .
                      "<b>How to use:</b>\n" .
                      "1️⃣ Type /imagine to start\n" .
                      "2️⃣ Send your image description\n" .
                      "3️⃣ Select the desired size\n" .
                      "4️⃣ Wait for your image to be generated!\n\n" .
                      "<b>Tips for better results:</b>\n" .
                      "• Be specific and detailed\n" .
                      "• Mention style, lighting, colors\n" .
                      "• Describe the mood or atmosphere\n" .
                      "• Use /styles to see available styles\n\n" .
                      "<b>Commands:</b>\n" .
                      "/imagine - Generate new image\n" .
                      "/styles - View available styles\n" .
                      "/cancel - Cancel current operation\n" .
                      "/help - Show this message";
        
        $this->telegram->sendMessage($chatId, $helpMessage);
    }

    /**
     * Handle /styles command
     */
    private function handleStyles(int|string $chatId): void
    {
        $styles = $this->settings['image']['styles'];
        
        $stylesMessage = "🎨 <b>Available Styles</b>\n\n" .
                        "You can include these keywords in your prompt:\n\n";
        
        foreach ($styles as $key => $value) {
            $stylesMessage .= "• <b>{$key}</b>: {$value}\n";
        }
        
        $stylesMessage .= "\n<i>Default style: realistic</i>";
        
        $this->telegram->sendMessage($chatId, $stylesMessage);
    }

    /**
     * Check if text is a command
     */
    public static function isCommand(string $text): bool
    {
        return str_starts_with(trim($text), '/');
    }
}
