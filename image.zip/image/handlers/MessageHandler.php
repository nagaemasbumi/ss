<?php
// ========================================
// FILE: handlers/MessageHandler.php
// ========================================

declare(strict_types=1);

namespace Handlers;

use Core\Telegram;
use Core\State;

class MessageHandler
{
    private Telegram $telegram;
    private State $state;
    private array $settings;

    public function __construct(Telegram $telegram, State $state, array $settings)
    {
        $this->telegram = $telegram;
        $this->state = $state;
        $this->settings = $settings;
    }

    /**
     * Handle incoming text message
     */
    public function handle(array $message): void
    {
        $chatId = $message['chat']['id'];
        $userId = $message['from']['id'];
        $text = $message['text'] ?? '';
        
        $currentState = $this->state->getState($userId);
        
        match ($currentState) {
            State::WAITING_PROMPT => $this->handlePromptInput($chatId, $userId, $text),
            State::IDLE => $this->handleIdleMessage($chatId),
            State::GENERATING => $this->handleGeneratingState($chatId),
            default => $this->handleUnknownState($chatId, $userId),
        };
    }

    /**
     * Handle prompt input from user
     */
    private function handlePromptInput(int|string $chatId, int|string $userId, string $text): void
    {
        // Validate prompt length
        $maxLength = $this->settings['bot']['max_prompt_length'];
        
        if (mb_strlen($text) > $maxLength) {
            $this->telegram->sendMessage(
                $chatId,
                "⚠️ Prompt is too long! Maximum length is {$maxLength} characters.\n" .
                "Your prompt: " . mb_strlen($text) . " characters.\n\n" .
                "Please send a shorter prompt."
            );
            return;
        }
        
        // Validate prompt content (basic sanitization)
        $text = trim($text);
        
        if (empty($text)) {
            $this->telegram->sendMessage(
                $chatId,
                "⚠️ Prompt cannot be empty. Please send a valid description."
            );
            return;
        }
        
        // Store the prompt
        $this->state->setData($userId, 'prompt', $text);
        $this->state->setState($userId, State::WAITING_SIZE);
        
        // Build size selection keyboard
        $keyboard = $this->buildSizeKeyboard();
        
        $sizeMessage = "📐 <b>Select image size:</b>\n\n" .
                      "Your prompt: <i>" . htmlspecialchars(mb_substr($text, 0, 100)) . 
                      (mb_strlen($text) > 100 ? '...' : '') . "</i>";
        
        $this->telegram->sendMessageWithKeyboard($chatId, $sizeMessage, $keyboard);
    }

    /**
     * Build inline keyboard for size selection
     */
    private function buildSizeKeyboard(): array
    {
        $sizes = $this->settings['image']['sizes'];
        $buttons = [];
        
        foreach ($sizes as $sizeKey => $sizeData) {
            $buttons[] = [
                [
                    'text' => "{$sizeKey} ({$sizeData['aspect']})",
                    'callback_data' => "imgsize:{$sizeKey}",
                ],
            ];
        }
        
        // Add cancel button
        $buttons[] = [
            [
                'text' => '❌ Cancel',
                'callback_data' => 'cancel',
            ],
        ];
        
        return $buttons;
    }

    /**
     * Handle message when user is in IDLE state
     */
    private function handleIdleMessage(int|string $chatId): void
    {
        $this->telegram->sendMessage(
            $chatId,
            "👋 Hello! Type /imagine to generate an image, or /help for more information."
        );
    }

    /**
     * Handle message when image is being generated
     */
    private function handleGeneratingState(int|string $chatId): void
    {
        $this->telegram->sendMessage(
            $chatId,
            "⏳ Your image is being generated. Please wait...\n\n" .
            "Type /cancel to abort."
        );
    }

    /**
     * Handle unknown state
     */
    private function handleUnknownState(int|string $chatId, int|string $userId): void
    {
        $this->state->reset($userId);
        $this->telegram->sendMessage(
            $chatId,
            "Something went wrong. Let's start over.\nType /imagine to generate an image."
        );
    }
}
