<?php
// ========================================
// FILE: index.php (Webhook Entry Point)
// ========================================

declare(strict_types=1);

// Error reporting for development (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

// Set timezone
date_default_timezone_set('UTC');

// Autoload classes (simple autoloader)
spl_autoload_register(function (string $class): void {
    $classMap = [
        'Core\\Telegram' => __DIR__ . '/core/Telegram.php',
        'Core\\OpenAI' => __DIR__ . '/core/OpenAI.php',
        'Core\\ImageService' => __DIR__ . '/core/ImageService.php',
        'Core\\State' => __DIR__ . '/core/State.php',
        'Handlers\\CommandHandler' => __DIR__ . '/handlers/CommandHandler.php',
        'Handlers\\MessageHandler' => __DIR__ . '/handlers/MessageHandler.php',
        'Handlers\\CallbackHandler' => __DIR__ . '/handlers/CallbackHandler.php',
    ];
    
    if (isset($classMap[$class])) {
        require_once $classMap[$class];
    }
});

// Load configuration
$env = require __DIR__ . '/config/env.php';
$settings = require __DIR__ . '/config/settings.php';

// Create log directory if not exists
$logDir = dirname($settings['paths']['logs']);
if (!is_dir($logDir)) {
    mkdir($logDir, 0755, true);
}

// Logger function
function logMessage(string $level, string $message, array $settings): void
{
    $logFile = $settings['paths']['logs'];
    $timestamp = date('Y-m-d H:i:s');
    $logLine = "[{$timestamp}] [{$level}] {$message}" . PHP_EOL;
    file_put_contents($logFile, $logLine, FILE_APPEND | LOCK_EX);
}

// Error handler
set_exception_handler(function (\Throwable $e) use ($settings): void {
    logMessage('CRITICAL', $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), $settings);
    http_response_code(200); // Return 200 to Telegram to prevent retries
    exit;
});

// Get webhook input
$input = file_get_contents('php://input');

if (empty($input)) {
    http_response_code(200);
    echo json_encode(['status' => 'ok', 'message' => 'No input']);
    exit;
}

$update = json_decode($input, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    logMessage('ERROR', 'Invalid JSON input: ' . json_last_error_msg(), $settings);
    http_response_code(200);
    exit;
}

// Log incoming update (for debugging - disable in production)
logMessage('DEBUG', 'Incoming update: ' . json_encode($update), $settings);

// Initialize services
try {
    $telegram = new Core\Telegram($env['telegram']['bot_token']);
    $openai = new Core\OpenAI($env['openai']['api_key'], $env['openai']['organization']);
    $imageService = new Core\ImageService($settings['paths']['tmp'], $settings['image']['webp_quality']);
    $state = new Core\State($settings['paths']['state']);
    
    // Initialize handlers
    $commandHandler = new Handlers\CommandHandler($telegram, $state, $settings);
    $messageHandler = new Handlers\MessageHandler($telegram, $state, $settings);
    $callbackHandler = new Handlers\CallbackHandler($telegram, $openai, $imageService, $state, $settings);
    
} catch (\Throwable $e) {
    logMessage('CRITICAL', 'Service initialization failed: ' . $e->getMessage(), $settings);
    http_response_code(200);
    exit;
}

// Route update to appropriate handler
try {
    // Handle callback query (inline keyboard button press)
    if (isset($update['callback_query'])) {
        $callbackHandler->handle($update['callback_query']);
    }
    // Handle message
    elseif (isset($update['message'])) {
        $message = $update['message'];
        
        // Check if it's a text message
        if (isset($message['text'])) {
            $text = $message['text'];
            
            // Check if it's a command
            if (Handlers\CommandHandler::isCommand($text)) {
                $commandHandler->handle($message);
            } else {
                $messageHandler->handle($message);
            }
        }
    }
    
    // Periodic cleanup (run occasionally)
    if (random_int(1, 100) <= 5) { // 5% chance
        $state->cleanup(86400); // Clean states older than 24 hours
        $imageService->cleanupOldFiles(3600); // Clean temp files older than 1 hour
    }
    
} catch (\Throwable $e) {
    logMessage('ERROR', 'Handler error: ' . $e->getMessage(), $settings);
    
    // Try to notify user of error
    try {
        $chatId = $update['message']['chat']['id'] 
                  ?? $update['callback_query']['message']['chat']['id'] 
                  ?? null;
        
        if ($chatId) {
            $telegram->sendMessage(
                $chatId,
                "❌ An error occurred. Please try again later.\n\nType /imagine to start again."
            );
        }
    } catch (\Throwable $notifyError) {
        logMessage('ERROR', 'Failed to notify user: ' . $notifyError->getMessage(), $settings);
    }
}

// Always return 200 to Telegram
http_response_code(200);
echo json_encode(['status' => 'ok']);
